var url = require('url');
// const e = require("express");
var express= require("express");
//const router = e.Router();
var router = express.Router();

const credential = {
    email:"admin@gmail.com",
    password:"admin"
}


function fn_message(req, res)
//  application.post('/login',(req,res)) =>
 {
    console.error("check");
    console.log(req.body.email + req.body.password)
    if(req.body.email == credential.email && req.body.password == credential.password)
    {
        console.log(req.body.email + req.body.password)
        req.session.user = req.body.email;
        var f_movie = req.body.f_movie;
    res.redirect('/route/dashboard?movie='+f_movie);
    
    let query = url.parse(req.url, true).query;
        console.log(req.url4);
        const searchParams = new URLSearchParams(query);
        const param1 = searchParams.get('movie');
        console.log("hello",param1);
        
     res.end('login Successful..!')
    }
    else{
        res.end("Invalid Username")
    }

}
function fn_message_register(req, res)
//  application.post('/login',(req,res)) =>
 {
    console.log("fn_message");
    // console.log(req.body.email + req.body.password)
    // if(req.body.email == credential.email && req.body.password == credential.password)
    // {
    //     console.log(req.body.email + req.body.password)
    //     req.session.user = req.body.email;
    //     var f_movie = req.body.f_movie;
    // res.redirect('/route/dashboard?movie='+f_movie);
    
    // let query = url.parse(req.url, true).query;
    //     console.log(req.url4);
    //     const searchParams = new URLSearchParams(query);
    //     const param1 = searchParams.get('movie');
    //     console.log("hello",param1);
        
     res.end('login Successful..!')
    }





function set_message(req){
    let query = url.parse(req.url, true).query;
    console.log(req.url)
}
//----------------------------------------------------------------------------------------------------------------
function fn_setup(){
    console.log("setup stub function called")
}
function fn_authentication(){
    console.log("authentication stub function called")
}
function fn_authorization(){
    console.log("authorization stub function called")
}
function fn_UploadDocument(){
    console.log("uploadDocument stub function called")
   

} 
function fn_Reason_document_types(){
    console.log("reason document type stub function called")
}
function fn_Finalize_Document_Rules(){
    console.log("Finalize Document Rules stub function called")
}
function fn_Apply_Document_Rules(){
    console.log("Apply Document Rules stub function called")
}
function fn_designate_document_as_good_bad(){
    console.log("designate document as good or bad stub function called")
}
function fn_Generate_invoice(){
    console.log("Generate invoice stub function called")
}
//----------------------------------------------------------------------------------------------------------------
// Get URL params and route to the function based on the params

//login user
router.post('/login',(req,res)=>{
    // console.log("welcome to AHCCCS")
    console.log("request",req.body.email)
    // console.log("response",res)
    fn_message(req, res);

    // console.error("check");
    // console.log(req.body.email + req.body.password)
    // if(req.body.email == credential.email && req.body.password == credential.password)
    // {
    //     console.log(req.body.email + req.body.password)
    //     req.session.user = req.body.email;
    //     res.end('login Successful..!')
    //     let query = url.parse(req.url, true).query;
    //     console.log(query.channel);
    //     const searchParams = new URLSearchParams(query);
    //     for (const [key, value] of searchParams.entries()) 
    //     {
    //         console.log(`${key}, ${value}`);
    //     }
    // }
    // else{
    //     res.end("Invalid Username")
    // }

});

router.post('/register',(req,res)=>{
    // console.log("welcome to AHCCCS")
    console.log("request",req.body.email)
    // console.log("response",res)
    fn_message_register(req, res);
});

// router.post('/dashboard',(req,res)=>{
//     set_message(req, res);

// });

// route for dashboard
router.get('/dashboard',(req,res)=>{ 
    // console.log("welcome to AHCCCS")
    // console.log("request",req)
    // console.log("response",res)
    if(req.session.user){
        res.render('dashboard',{user:req.session.user})
        console.log(req.url);
        let query = url.parse(req.url, true).query;
        console.log(req.url);
        const searchParams = new URLSearchParams(query);
        const param1 = searchParams.get('movie');
        console.log(param1);
        
        //res.render('input', { param1 });
    }else{
        res.send("Unauthorize User")
    }
});
// route for logout
router.get('/logout',(req,res)=>
req.session.destroy(function(error){
if(error){
    console.log(error);
    res.send("error")
}else{
    res.render('base',{title:"AHCCCS",logout:"logout Successfully...!"})
}

}));
router.post('/upload',(req,res)=>{
    fn_UploadDocument(req, res);

});



module.exports=router;
